package com.efjerryyang.defendthefrontline.subscriber;

public interface BombSubscriber {
    void bombExplode();
}
