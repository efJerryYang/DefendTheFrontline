package com.efjerryyang.defendthefrontline.subscriber;

public interface BloodSubscriber {
//    void
}
