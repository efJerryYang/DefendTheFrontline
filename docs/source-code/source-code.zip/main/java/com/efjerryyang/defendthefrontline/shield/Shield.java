//package com.efjerryyang.defendthefrontline.shield;
//
//import edu.hitsz.aircraft.AbstractAircraft;
//import edu.hitsz.basic.AbstractFlyingObject;
//
//public class Shield extends AbstractFlyingObject {
//    public Shield(AbstractAircraft aircraft) {
//        super(aircraft.getLocationX(), aircraft.getLocationY(), aircraft.getSpeedX(), aircraft.getSpeedY());
//    }
//
//    public void forward() {
//    }
//
//}
